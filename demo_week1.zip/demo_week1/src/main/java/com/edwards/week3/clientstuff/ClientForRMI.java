package com.edwards.week3.clientstuff;

import com.edwards.week3.commonstuff.Calculator;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClientForRMI {

    public static void main(String[] args ) throws RemoteException, NotBoundException {
        Registry clientReg = LocateRegistry.getRegistry("localhost", 2091);
        Calculator toUse = (Calculator) clientReg.lookup("the_calculator");

        System.out.println(toUse.addition(10,5));

    }


}
