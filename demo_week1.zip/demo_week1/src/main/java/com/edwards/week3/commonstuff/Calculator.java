package com.edwards.week3.commonstuff;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Calculator extends Remote {

    public int addition(int a, int b) throws RemoteException;
    public int subtraction(int a, int b) throws RemoteException;
    public double multiplication (double a, double b) throws RemoteException;
}
