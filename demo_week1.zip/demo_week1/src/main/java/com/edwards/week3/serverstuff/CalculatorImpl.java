package com.edwards.week3.serverstuff;

import com.edwards.week3.commonstuff.Calculator;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorImpl extends UnicastRemoteObject implements Calculator {
    protected CalculatorImpl() throws RemoteException {}


    @Override
    public int addition(int a, int b) {
        return a + b;
    };

    @Override
    public int subtraction(int a, int b) {
        return a - b;
    };

    @Override
    public double multiplication (double a, double b) {
        return  a * b;
    };

}
