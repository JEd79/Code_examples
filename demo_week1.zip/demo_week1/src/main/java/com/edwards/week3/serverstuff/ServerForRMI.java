package com.edwards.week3.serverstuff;

import com.edwards.week3.commonstuff.Calculator;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServerForRMI {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException {
        Registry theRegistry = LocateRegistry.createRegistry(2091);

        Calculator calc = new CalculatorImpl();
        theRegistry.bind("the_calculator", calc);

    }
}
