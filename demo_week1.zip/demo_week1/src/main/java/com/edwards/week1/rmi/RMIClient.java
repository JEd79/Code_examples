package com.edwards.week1.rmi;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIClient {
    static void main(String[] args) throws NotBoundException, IOException {
        Registry registry = LocateRegistry.getRegistry("127.0.0.1", 3001);
        DuckInterface instance = (DuckInterface) registry.lookup("Duck");

        System.out.println("Duck is online!");
        System.out.println("Ducks name: " + instance.getName());
        System.out.println(instance.quack());
    }
}
