package com.edwards.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPClient {

    public static void main(String[] args) throws IOException {
        DatagramSocket socket = new DatagramSocket();

        String content = "Hello Server!";
        DatagramPacket sendPacket = new DatagramPacket(content.getBytes(), content.getBytes().length,
                InetAddress.getByName("127.0.0.1"), 3000);
        socket.send(sendPacket);
        System.out.println("Program sent packet.");
    }
}
