package com.edwards.week1.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Duck extends UnicastRemoteObject implements DuckInterface{
    private String name;
    private String quackMessage;

    public Duck (String name, String quackMessage) throws RemoteException {
        this.name = name;
        this.quackMessage = quackMessage;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String quack() throws RemoteException {
        return "The duck says: " + quackMessage;
    }

}
