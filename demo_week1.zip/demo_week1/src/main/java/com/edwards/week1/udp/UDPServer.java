package com.edwards.udp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;

public class UDPServer {
    public static void main(String[] args) throws IOException {
        DatagramSocket serverSocket = new DatagramSocket(3000);

        DatagramPacket receivePacket = new DatagramPacket(new byte[1024], 1024);
        serverSocket.receive(receivePacket); //will wait until a packet is received that matches requirements e.g. 1024 bytes

        String dataReceived = new String(receivePacket.getData(),0,receivePacket.getLength());


        System.out.println("Server receive packet: " + dataReceived);
        System.out.println("Server receive packet length: " + receivePacket.getLength());


    }

}
