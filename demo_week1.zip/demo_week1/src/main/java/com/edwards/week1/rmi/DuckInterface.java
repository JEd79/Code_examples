package com.edwards.week1.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DuckInterface extends Remote {
    public String getName() throws RemoteException;
    public String quack() throws RemoteException;
}
