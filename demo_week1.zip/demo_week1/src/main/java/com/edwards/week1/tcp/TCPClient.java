package com.edwards.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TCPClient {
    public static void main(String[] args) throws IOException {
        Socket toServer = new Socket("127.0.0.1", 3000);

        PrintWriter out = new PrintWriter(toServer.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(toServer.getInputStream()));

        String msgFromServer = in.readLine();
        System.out.println(msgFromServer);

        out.println("Hi server!");

    }
}
