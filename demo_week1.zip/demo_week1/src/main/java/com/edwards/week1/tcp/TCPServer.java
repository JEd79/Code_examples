package com.edwards.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer {
    public static void main() throws IOException, InterruptedException {

        ServerSocket serverSocket = new ServerSocket(3000);
        Socket client = serverSocket.accept();

        PrintWriter out = new PrintWriter(client.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

        out.println("Hello Client! Welcome.");

        String msgFromClient = in.readLine();
        System.out.println(msgFromClient);
    }
}
