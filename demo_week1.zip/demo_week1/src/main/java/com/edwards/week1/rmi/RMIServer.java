package com.edwards.week1.rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIServer {
    static void main() throws RemoteException {
        Registry registry = LocateRegistry.createRegistry(3001);
        DuckInterface instance = new Duck("Jannet", "Quickquack");
        registry.rebind("Duck", instance);

        System.out.println("And now we wait...");
    }
}
