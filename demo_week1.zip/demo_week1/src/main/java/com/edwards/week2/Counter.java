package com.edwards.week2;

public class Counter {

    private int count = 0;
//    //Original code
//    public void increment() {
//        count++;
//    }

    //Option with Synchronized
    //Every object in java has a lock
    public synchronized void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}
