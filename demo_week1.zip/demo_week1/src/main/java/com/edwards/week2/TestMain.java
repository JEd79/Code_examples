package com.edwards.week2;

public class TestMain {
    public static void main(String[] args ) throws InterruptedException {
        Counter count = new Counter();

        DataBox box = new DataBox();

        Thread t3 = new Thread(()-> {
            int count2 = 0;
            while(true) {
                box.putMessageInBox("Number: "+count2);
                count2++;
            }
        });

        Thread t4 = new Thread(()-> {
            while(true) {
                String message = box.getMessageOutOfBox();
                System.out.println(message);
            }
        });

        t3.start();
        t4.start();
        t3.join();
        t4.join();



        Thread t1 = new Thread(()-> {
            for(int i = 0; i<100000; i++) {
                count.increment();
            }
        });

        Thread t2 = new Thread(()-> {
            for(int i = 0; i<100000; i++) {
                count.increment();
            }
        });

        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println(count.getCount());



//    //Main for Thread
//    public static void main(String[] args ) throws InterruptedException {
//        MyThread t = new MyThread(100);
//        t.start();
//        t.join();
//        System.out.println(t.getCount());
//    }

//    //Main for Runnable
//    public static void main(String[] args ) throws InterruptedException {
//        MyThread toRun = new MyThread(100);
//        Thread t = new Thread(toRun);
//        t.start();
//        t.join();
//        System.out.println(toRun.getCount());
//    }


    }
}

