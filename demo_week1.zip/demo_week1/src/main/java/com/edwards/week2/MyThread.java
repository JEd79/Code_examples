package com.edwards.week2;

//Option with Thread
public class MyThread extends Thread{
    private int count;
    private int max;

    public MyThread(int max) {
        this.max = max;
    }

    @Override
    public void run() {
        for(int i=0; i < max; i++) {
            count = count + i;
        }
    }

    public int getCount() {
        return count;
    }
}

////Option with Runnable
//public class MyThread implements Runnable{
//
//    private int count;
//    private int max;
//
//    public MyThread(int max) {
//        this.max = max;
//    }
//
//    @Override
//    public void run() {
//        for(int i=0; i < max; i++) {
//            count = count + i;
//        }
//    }
//
//    public int getCount() {
//        return count;
//    }
//}
