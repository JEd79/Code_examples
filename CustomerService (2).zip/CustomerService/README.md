# Customer REST Service (CSF2753)

A simple Java 17 / Spring Boot project that follows the methods in the AdultDataset, Iris and FirstREST examples. It implements the **eight operations from the coursework design**.

## Open and run

1. Unzip `CustomerService.zip`.
2. Open the `CustomerService` folder in **IntelliJ IDEA** as a Maven project (open its `pom.xml` if prompted).
3. Use **JDK 17 or newer** and allow IntelliJ/Maven to download the Spring Boot dependencies on the first run (Internet access is needed once).
4. Open `src/main/java/uk/ac/swan/customers/CustomerServiceApplication.java`.
5. Click the green Run button next to `main`. The console should say `Loaded 50 customers from CSV`.
6. Open `http://localhost:8080/2545959/customers/statistics` in a browser. It should show counts of 34 ACTIVE, 9 SUSPENDED and 7 CLOSED.

Alternatively, from the `CustomerService` folder, run `./mvnw spring-boot:run` (macOS/Linux) or `mvnw.cmd spring-boot:run` (Windows).

**Note:** The student number `2545959` comes from your draft. If it needs changing, replace it in `CustomerController.java`, `requests.http` and the URLs below.

## Test the eight operations

| Operation | Method and path |
|---|---|
| Get all | `GET /2545959/customers` |
| Get one | `GET /2545959/customers/CUS001` |
| Filter | `GET /2545959/customers?account_status=SUSPENDED&town=Leeds` |
| Date range | `GET /2545959/customers?registered_from=2024-01-01&registered_to=2024-03-31` |
| Status counts | `GET /2545959/customers/statistics` |
| Create | `POST /2545959/customers` with JSON body |
| Replace | `PUT /2545959/customers/CUS051` with JSON body |
| Delete | `DELETE /2545959/customers/CUS051` |

The easiest way to try **all eight** is to open the included `requests.http` in IntelliJ (if its HTTP client is available). You can also copy those requests into Postman. Run POST before PUT and DELETE because the examples use the new customer `CUS051`.

For simple GET requests, paste the URL into your browser. Browser requests cannot easily send POST, PUT or DELETE; use an HTTP client for those.

## CSV and dates

- The included `src/main/resources/data/customers.csv` is the copy uploaded in this conversation. It contains **50 records** and stores dates as `yyyy-MM-dd`.
- The **Notepad screenshot** showed a second copy with dates as `dd/MM/yyyy`. The reader is written to accept **both date formats**, so you can replace the included CSV with your Notepad version if its columns are otherwise the same.
- Java stores registration dates as `LocalDate`. The JSON API accepts and returns `yyyy-MM-dd` dates (for example, `2022-05-23`).
- Blank optional address and secondary-contact fields become `null`.

## How the Java classes relate to the lectures

- **`models/Customer.java`:** Customer fields, getters, setters and an empty constructor (like the lecturer's `Adult` and `Duck` models).
- **`services/CustomerReaderService.java`:** Reads the CSV into a `HashMap`, based on the uploaded `AdultReaderService` and `IrisReaderService`.
- **`controllers/CustomerController.java`:** Uses `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`, path/query parameters and `ResponseEntity`, like the lecturer's controllers.
- **`synchronized (lock)`:** Protects shared `HashMap` reads and writes, using synchronization covered in Lecture 2.

## Important limits of this simple implementation

- **Changes are kept in memory only.** When you restart the server, the original CSV is loaded again. POST/PUT/DELETE do not edit the CSV file.
- It is a **coursework learning example**, not a real DVLA system. It has no login or permissions, so **only use synthetic customer data and run it locally**.
- CSV reading uses a simple comma split suited to the uploaded dataset. It does not support more complicated CSV values that contain quoted commas.
- Spring Boot handles HTTP 415 and general unexpected server errors; the controller returns clear error JSON for common invalid input, missing records and duplicate IDs.
- The standard JSON request date format is `yyyy-MM-dd`, even when the source CSV used `dd/MM/yyyy`.

## Expected status codes

- `200` for successful GET and PUT; `201` for successful POST; `204` for successful DELETE.
- `400` for bad input, `404` for non-existent customers, `409` for duplicate IDs.
- Spring Boot returns `415` for unsupported request-body content types and `500` for unexpected server exceptions.

### Note about testing

This project was generated from the uploaded teaching examples. The CSV-loading code can be tested separately with Java 17; a full Spring Boot launch needs Maven dependencies to be installed or downloaded on your machine.
