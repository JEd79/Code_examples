package uk.ac.swan.customers.controllers;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.converter.HttpMessageNotReadableException;

import uk.ac.swan.customers.models.Customer;
import uk.ac.swan.customers.services.CustomerReaderService;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/2545959/customers")
public class CustomerController {

    // Shared records, like AdultDataset_solution. A common lock protects the HashMap.
    private final HashMap<String, Customer> customers = new HashMap<>();
    private final Object lock = new Object();

    @EventListener(ApplicationReadyEvent.class)
    public void initialise() {
        try {
            HashMap<String, Customer> fromCsv = CustomerReaderService.readCustomers();
            synchronized (lock) {
                customers.clear();
                customers.putAll(fromCsv);
            }
            System.out.println("Loaded " + fromCsv.size() + " customers from CSV");
        } catch (IOException e) {
            throw new RuntimeException("Could not load customers.csv", e);
        }
    }

    // The same simple {error, message} format is used for expected errors.
    private ResponseEntity<Map<String, String>> error(HttpStatus code, String message) {
        Map<String, String> result = new HashMap<>();
        result.put("error", code.getReasonPhrase());
        result.put("message", message);
        return ResponseEntity.status(code).body(result);
    }

    private boolean validId(String id) {
        return id != null && id.matches("CUS\\d{3}");
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private boolean validStatus(String value) {
        return value != null && (value.equalsIgnoreCase("ACTIVE")
                || value.equalsIgnoreCase("SUSPENDED")
                || value.equalsIgnoreCase("CLOSED"));
    }

    private boolean validCustomer(Customer customer) {
        return customer != null && validId(customer.getCustomer_id())
                && hasText(customer.getOrganisation_name())
                && hasText(customer.getAddress_line_1())
                && hasText(customer.getTown())
                && hasText(customer.getPostcode())
                && hasText(customer.getPrimary_contact_name())
                && hasText(customer.getPrimary_contact_email())
                && hasText(customer.getPrimary_contact_phone())
                && validStatus(customer.getAccount_status())
                && customer.getDate_registered() != null;
    }

    // GET /customers (all), ?account_status=, ?town=, or date range.
    @GetMapping
    public ResponseEntity<?> getCustomers(
            @RequestParam(required = false, name = "account_status") String status,
            @RequestParam(required = false) String town,
            @RequestParam(required = false, name = "registered_from") String from,
            @RequestParam(required = false, name = "registered_to") String to) {

        if (status != null && !validStatus(status)) {
            return error(HttpStatus.BAD_REQUEST, "Unknown account status");
        }
        if ((from == null) != (to == null)) {
            return error(HttpStatus.BAD_REQUEST, "Both registration dates are required");
        }

        LocalDate start = null;
        LocalDate end = null;
        if (from != null) {
            try {
                start = LocalDate.parse(from); // Query dates must use yyyy-MM-dd.
                end = LocalDate.parse(to);
            } catch (DateTimeParseException e) {
                return error(HttpStatus.BAD_REQUEST, "Dates must use yyyy-MM-dd");
            }
            if (start.isAfter(end)) {
                return error(HttpStatus.BAD_REQUEST, "Start date must be before or equal to end date");
            }
        }

        List<Customer> result = new ArrayList<>();
        synchronized (lock) {
            for (Customer c : customers.values()) {
                if (status != null && !c.getAccount_status().equalsIgnoreCase(status)) {
                    continue;
                }
                if (town != null && !c.getTown().equalsIgnoreCase(town)) {
                    continue;
                }
                if (start != null && (c.getDate_registered().isBefore(start)
                        || c.getDate_registered().isAfter(end))) {
                    continue;
                }
                result.add(c);
            }
        }
        return ResponseEntity.ok(result); // [] is valid when no records match.
    }

    // GET /customers/statistics: count ACTIVE, SUSPENDED, CLOSED.
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Integer>> getStatistics() {
        Map<String, Integer> counts = new HashMap<>();
        counts.put("ACTIVE", 0);
        counts.put("SUSPENDED", 0);
        counts.put("CLOSED", 0);
        synchronized (lock) {
            for (Customer c : customers.values()) {
                String status = c.getAccount_status();
                counts.put(status, counts.get(status) + 1);
            }
        }
        return ResponseEntity.ok(counts);
    }

    // GET /customers/CUS001
    @GetMapping("/{customer_id}")
    public ResponseEntity<?> getCustomer(@PathVariable String customer_id) {
        if (!validId(customer_id)) {
            return error(HttpStatus.BAD_REQUEST, "Invalid customer ID");
        }
        synchronized (lock) {
            Customer found = customers.get(customer_id);
            if (found == null) {
                return error(HttpStatus.NOT_FOUND, "Customer " + customer_id + " does not exist.");
            }
            return ResponseEntity.ok(found);
        }
    }

    // POST /customers with a JSON body. ID is supplied by the client.
    @PostMapping
    public ResponseEntity<?> createCustomer(@RequestBody Customer customer) {
        if (!validCustomer(customer)) {
            return error(HttpStatus.BAD_REQUEST, "Missing or invalid customer fields");
        }
        customer.setAccount_status(customer.getAccount_status().toUpperCase());
        synchronized (lock) {
            if (customers.containsKey(customer.getCustomer_id())) {
                return error(HttpStatus.CONFLICT, "Customer ID " + customer.getCustomer_id() + " already exists.");
            }
            customers.put(customer.getCustomer_id(), customer);
        }
        // Same 201 response as AdultDataset, with a Location header.
        return ResponseEntity.status(HttpStatus.CREATED)
                .header("Location", "/2545959/customers/" + customer.getCustomer_id())
                .body(customer);
    }

    // PUT /customers/CUS001: replace all editable fields, keep path ID.
    @PutMapping("/{customer_id}")
    public ResponseEntity<?> updateCustomer(@PathVariable String customer_id,
                                             @RequestBody Customer updated) {
        if (!validId(customer_id)) {
            return error(HttpStatus.BAD_REQUEST, "Invalid customer ID");
        }
        if (updated != null && updated.getCustomer_id() != null
                && !customer_id.equals(updated.getCustomer_id())) {
            return error(HttpStatus.BAD_REQUEST, "Customer ID in body must match URI");
        }
        if (updated == null) {
            return error(HttpStatus.BAD_REQUEST, "Missing customer information");
        }
        updated.setCustomer_id(customer_id);
        if (!validCustomer(updated)) {
            return error(HttpStatus.BAD_REQUEST, "Missing or invalid customer fields");
        }
        updated.setAccount_status(updated.getAccount_status().toUpperCase());
        synchronized (lock) {
            if (!customers.containsKey(customer_id)) {
                return error(HttpStatus.NOT_FOUND, "Customer " + customer_id + " does not exist.");
            }
            customers.put(customer_id, updated);
        }
        return ResponseEntity.ok(updated);
    }

    // DELETE /customers/CUS001
    @DeleteMapping("/{customer_id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable String customer_id) {
        if (!validId(customer_id)) {
            return error(HttpStatus.BAD_REQUEST, "Invalid customer ID");
        }
        synchronized (lock) {
            if (customers.remove(customer_id) == null) {
                return error(HttpStatus.NOT_FOUND, "Customer " + customer_id + " does not exist.");
            }
        }
        return ResponseEntity.noContent().build();
    }

    // Spring Boot already returns 400 for malformed JSON. Use our error shape too.
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, String>> badJson() {
        return error(HttpStatus.BAD_REQUEST, "Invalid JSON or date format");
    }
}
