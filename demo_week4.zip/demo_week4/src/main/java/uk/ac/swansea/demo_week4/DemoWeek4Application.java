package uk.ac.swansea.demo_week4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWeek4Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoWeek4Application.class, args);
	}

}
