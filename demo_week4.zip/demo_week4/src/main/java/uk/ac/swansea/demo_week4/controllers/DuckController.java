package uk.ac.swansea.demo_week4.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uk.ac.swansea.demo_week4.models.Duck;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/ducks")
public class DuckController {
    private static int duckIdCounter = 0;
    private static List<Duck> theDucks = new ArrayList<>();
//    @GetMapping
//    public String getSomeDuck() {
//        return "Hello from the ducks";
//    }

//    @GetMapping
//    public int getSomeDuck() {
//        return 123;
//    }

//    @GetMapping
//    public Duck getSomeDuck() {
//        return new Duck("Wilfred", 10);
//    }

    @GetMapping
    public List<Duck> getSomeDuck() {
        return theDucks;
    }

    @GetMapping("/count")
    public int getNumOfDucks() {
        return theDucks.size();
    }


    @PostMapping
    public ResponseEntity<Duck> createDuck(@RequestBody Duck someDuck) {

        if(someDuck.getName() == null) {
            //throw new IllegalArgumentException("No name specified");
            return ResponseEntity.badRequest().body(someDuck);
        }

        int duckId = duckIdCounter;
        someDuck.setId(duckId);
        duckIdCounter++;
        theDucks.add(someDuck);
        return ResponseEntity.ok(someDuck);
    }

    @DeleteMapping("{id}")
    public void deleteDuck(@PathVariable int id) {
        theDucks.removeIf(a -> a.getId() == id);
    }
}
