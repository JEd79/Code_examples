package uk.ac.swan.customers.services;

import uk.ac.swan.customers.models.Customer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

// Based on the CSV readers in the AdultDataset and Iris examples.
public class CustomerReaderService {
    private static final String FILE = "data/customers.csv";
    private static final DateTimeFormatter UK_DATE =
            DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // Blank address and secondary contact fields are allowed.
    private static String optionalField(String text) {
        if (text.isBlank()) {
            return null;
        }
        return text;
    }

    // The Notepad CSV uses dd/MM/yyyy; the uploaded CSV uses yyyy-MM-dd.
    // Accept either on loading, then keep a LocalDate in each Customer.
    public static LocalDate parseCsvDate(String date) {
        if (date.contains("/")) {
            return LocalDate.parse(date, UK_DATE);
        }
        return LocalDate.parse(date); // ISO yyyy-MM-dd
    }

    public static HashMap<String, Customer> readCustomers() throws IOException {
        HashMap<String, Customer> customers = new HashMap<>();
        InputStream file = CustomerReaderService.class.getClassLoader().getResourceAsStream(FILE);
        if (file == null) {
            throw new IOException("Cannot find " + FILE);
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(file, StandardCharsets.UTF_8))) {
            br.readLine(); // Skip the column names.
            String line;
            while ((line = br.readLine()) != null) {
                // This dataset has 14 simple columns, without quoted commas.
                String[] data = line.split(",", -1); // -1 keeps empty columns.
                if (data.length != 14) {
                    throw new IOException("Expected 14 columns in: " + line);
                }
                for (int i = 0; i < data.length; i++) {
                    data[i] = data[i].trim();
                }

                Customer customer = new Customer();
                customer.setCustomer_id(data[0]);
                customer.setOrganisation_name(data[1]);
                customer.setAddress_line_1(data[2]);
                customer.setAddress_line_2(optionalField(data[3]));
                customer.setTown(data[4]);
                customer.setPostcode(data[5]);
                customer.setPrimary_contact_name(data[6]);
                customer.setPrimary_contact_email(data[7]);
                customer.setPrimary_contact_phone(data[8]);
                customer.setSecondary_contact_name(optionalField(data[9]));
                customer.setSecondary_contact_email(optionalField(data[10]));
                customer.setSecondary_contact_phone(optionalField(data[11]));
                customer.setAccount_status(data[12]);
                customer.setDate_registered(parseCsvDate(data[13]));

                if (customers.containsKey(customer.getCustomer_id())) {
                    throw new IOException("Duplicate ID in CSV: " + customer.getCustomer_id());
                }
                customers.put(customer.getCustomer_id(), customer);
            }
        }
        return customers;
    }
}
