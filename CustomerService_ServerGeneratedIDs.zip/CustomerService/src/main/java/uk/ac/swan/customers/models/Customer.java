package uk.ac.swan.customers.models;

import java.time.LocalDate;

// One row from customers.csv. Names match the CSV and the JSON examples.
public class Customer {
    private String customer_id;
    private String organisation_name;
    private String address_line_1;
    private String address_line_2;
    private String town;
    private String postcode;
    private String primary_contact_name;
    private String primary_contact_email;
    private String primary_contact_phone;
    private String secondary_contact_name;
    private String secondary_contact_email;
    private String secondary_contact_phone;
    private String account_status;
    private LocalDate date_registered;

    // Spring Boot needs an empty constructor for JSON request bodies.
    public Customer() {
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getOrganisation_name() {
        return organisation_name;
    }

    public void setOrganisation_name(String organisation_name) {
        this.organisation_name = organisation_name;
    }

    public String getAddress_line_1() {
        return address_line_1;
    }

    public void setAddress_line_1(String address_line_1) {
        this.address_line_1 = address_line_1;
    }

    public String getAddress_line_2() {
        return address_line_2;
    }

    public void setAddress_line_2(String address_line_2) {
        this.address_line_2 = address_line_2;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getPrimary_contact_name() {
        return primary_contact_name;
    }

    public void setPrimary_contact_name(String primary_contact_name) {
        this.primary_contact_name = primary_contact_name;
    }

    public String getPrimary_contact_email() {
        return primary_contact_email;
    }

    public void setPrimary_contact_email(String primary_contact_email) {
        this.primary_contact_email = primary_contact_email;
    }

    public String getPrimary_contact_phone() {
        return primary_contact_phone;
    }

    public void setPrimary_contact_phone(String primary_contact_phone) {
        this.primary_contact_phone = primary_contact_phone;
    }

    public String getSecondary_contact_name() {
        return secondary_contact_name;
    }

    public void setSecondary_contact_name(String secondary_contact_name) {
        this.secondary_contact_name = secondary_contact_name;
    }

    public String getSecondary_contact_email() {
        return secondary_contact_email;
    }

    public void setSecondary_contact_email(String secondary_contact_email) {
        this.secondary_contact_email = secondary_contact_email;
    }

    public String getSecondary_contact_phone() {
        return secondary_contact_phone;
    }

    public void setSecondary_contact_phone(String secondary_contact_phone) {
        this.secondary_contact_phone = secondary_contact_phone;
    }

    public String getAccount_status() {
        return account_status;
    }

    public void setAccount_status(String account_status) {
        this.account_status = account_status;
    }

    public LocalDate getDate_registered() {
        return date_registered;
    }

    public void setDate_registered(LocalDate date_registered) {
        this.date_registered = date_registered;
    }

}
